package com.example.multiple_permissions;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import android.provider.ContactsContract;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.securedroid.SecContentResolver;
import com.example.securedroid.SecContext;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class FormCalendar extends AppCompatActivity implements View.OnClickListener {

    Button submit;
    EditText name;
    EditText email;
    EditText age;
    EditText phoneno;
    String Name, Email, Age, Phoneno;

    StringBuffer sb;
    String fileName;
    File file;
    SecContext secContext;
    PrintWriter out;
    FileWriter fileWriter;
    BufferedWriter bufferedWriter;

    SecContentResolver secContentResolver;
    Cursor cur;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_calendar);

        submit = findViewById(R.id.submit);
        submit.setOnClickListener(this);

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        age = findViewById(R.id.age);
        phoneno = findViewById(R.id.phoneno);

        secContext = new SecContext(this);
    }

    @Override
    public void onClick(View view) {

        Name = name.getText().toString();
        Email = email.getText().toString();
        Age = age.getText().toString();
        Phoneno = phoneno.getText().toString();

        sb = new StringBuffer();
        sb.append("Name: " + Name + "\nEmail: " + Email + "\nAge: " + Age + "\nPhone No: " + Phoneno + "\n");

        if ( ContextCompat.checkSelfPermission( this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Please give Read External Storage permission!!", Toast.LENGTH_SHORT).show();
            return;
        }
        if ( ContextCompat.checkSelfPermission( this, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED) {
            secContentResolver = new SecContentResolver(this);

            Uri uri = CalendarContract.Calendars.CONTENT_URI;

            cur = secContentResolver.query(uri, null, null, null, null);

            while (cur.moveToNext()) {
                String displayName = cur.getString(cur.getColumnIndex(CalendarContract.Calendars.CALENDAR_DISPLAY_NAME));
                String accountName = cur.getString(cur.getColumnIndex(CalendarContract.Calendars.ACCOUNT_NAME));
                sb.append("\nDisplay Name : " + displayName + ", Account Name:admin " + accountName);
            }
        }

        fileName = "Information.txt";
        file = new File(secContext.getExternalFilesDir(null), fileName);

        try {
            if (!file.exists()) {
                file.createNewFile();
            }
            fileWriter = new FileWriter(file.getAbsoluteFile(), false);
            bufferedWriter = new BufferedWriter(fileWriter);
            out = new PrintWriter(bufferedWriter);
            out.println(sb);
            out.close();


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null)
                    out.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                if (bufferedWriter != null)
                    bufferedWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (fileWriter != null)
                    fileWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
