package com.example.multiple_permissions;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText username;
    EditText password;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.username);
        password = findViewById(R.id.pass);
        submit = findViewById(R.id.submit);
        submit.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.submit){
            if(username.getText().toString().compareTo("admin") == 0 && password.getText().toString().compareTo("admin") == 0){
                Toast.makeText(this, "Logged In!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, Display.class);
                startActivity(intent);
            }
            else{
                Toast.makeText(this, "Please Enter Correct Credentials!", Toast.LENGTH_SHORT).show();
            }
        }

    }
}
