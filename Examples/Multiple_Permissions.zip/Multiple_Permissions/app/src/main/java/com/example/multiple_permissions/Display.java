package com.example.multiple_permissions;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Display extends AppCompatActivity implements View.OnClickListener {

    Button formCalendar;
    Button contactsSms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        formCalendar = findViewById(R.id.form_calendar);
        contactsSms = findViewById(R.id.contacts_sms);
        formCalendar.setOnClickListener(this);
        contactsSms.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.form_calendar){
                Intent intent = new Intent(this, FormCalendar.class);
                startActivity(intent);
        }
        if(view.getId() == R.id.contacts_sms){
                Intent intent = new Intent(this, ContactsSms.class);
                startActivity(intent);
        }
    }
}
