package com.example.gps_sms;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.securedroid.SecLocationManager;
import com.example.securedroid.SecSmsManager;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, LocationListener{

    Button btn;
    EditText latitude;
    EditText longitude;
    SecLocationManager secLocationManager;
    boolean isGPSEnabled;
    boolean isNetworkEnabled;
    Location location;
    SecSmsManager secSmsManager;
    int lat;
    int lng;
    String phoneNo;
    String msg;

    @SuppressLint("ServiceCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.btn);
        btn.setOnClickListener(this);

        latitude = findViewById(R.id.latitude);
        longitude = findViewById(R.id.longitude);

        isGPSEnabled = false;
        isNetworkEnabled = false;

    }

    @Override
    public void onClick(View view) {

        if ( Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission( this, android.Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission( this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Please give Location service permission!!", Toast.LENGTH_SHORT).show();
            return;
        }

        secLocationManager = new SecLocationManager(this);
        secSmsManager = new SecSmsManager(this);
        phoneNo = "+918982918682";

        isGPSEnabled = secLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        isNetworkEnabled = secLocationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

        secLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, this);

        if(isNetworkEnabled){
            location = secLocationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if(location != null){
                lat = (int) (location.getLatitude());
                lng = (int) (location.getLongitude());

                latitude.setText("Latitude: " + lat);
                longitude.setText("Longitude: " + lng);

                msg = "Latitude: " + lat + "; Longitude: " + lng;

                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }else{
                    secSmsManager.sendTextMessage(phoneNo, null, msg, null, null);
                }

            }
            else{
                latitude.setText("NULL");
                longitude.setText("NULL");
            }
        }
        else if(isGPSEnabled){
            location = secLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(location != null){
                lat = (int) (location.getLatitude());
                lng = (int) (location.getLongitude());

                latitude.setText("Latitude: " + lat);
                longitude.setText("Longitude: " + lng);

                msg = "Latitude: " + lat + "; Longitude: " + lng;

                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }else{
                    secSmsManager.sendTextMessage(phoneNo, null, msg, null, null);
                }
            }
            else{
                latitude.setText("NULL");
                longitude.setText("NULL");
            }
        }else if(!isNetworkEnabled && !isGPSEnabled){
            Toast.makeText(this, "Please ON your location service!!", Toast.LENGTH_SHORT).show();
        }


    }

    @Override
    public void onLocationChanged(Location location) {
        lat = (int) (location.getLatitude());
        lng = (int) (location.getLongitude());
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }
}
